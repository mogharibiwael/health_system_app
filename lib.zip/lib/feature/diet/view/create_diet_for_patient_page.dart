import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/class/status_request.dart';
import '../../../core/constant/theme/colors.dart';
import '../../../core/routes/app_route.dart';
import '../../../core/service/diet_calculator_service.dart';
import '../../../core/shared/widgets/app_bar.dart';
import '../controller/diet_controller.dart';
import '../model/exchange_model.dart';
import '../service/diet_payload_builder.dart';

/// Doctor-only: create diet plan for a specific patient.
/// When opened from wizard (distribution, targets, exchange_plan in args),
/// auto-fills and builds meals from exchange distribution.
class CreateDietForPatientPage extends GetView<DietController> {
  const CreateDietForPatientPage({super.key});

  @override
  Widget build(BuildContext context) {
    final args = (Get.arguments as Map?) ?? {};
    final patientId = (args["patient_id"] is int)
        ? args["patient_id"] as int
        : int.tryParse("${args["patient_id"]}") ?? 0;
    final patientName = (args["patient_name"] ?? "").toString();
    final doctorId = (args["doctor_id"] is int)
        ? args["doctor_id"] as int
        : int.tryParse("${args["doctor_id"]}") ?? 0;
    final periodsRaw = args["periods"];
    final periods = periodsRaw is List
        ? (periodsRaw).map((e) => Map<String, dynamic>.from(e as Map)).toList()
        : <Map<String, dynamic>>[];
    final distributionRaw = args["distribution"];
    Map<String, Map<String, int>> distribution = {};
    if (distributionRaw is Map) {
      for (final e in (distributionRaw as Map).entries) {
        final k = e.key.toString();
        final v = e.value;
        if (v is Map) {
          final inner = <String, int>{};
          for (final ie in (v as Map).entries) {
            inner[ie.key.toString()] = (ie.value is int) ? ie.value as int : 0;
          }
          distribution[k] = inner;
        }
      }
    }
    final targets = args["targets"] as DietTargetsResult?;
    DailyExchangePlan? exchangePlan;
    if (args["exchange_plan"] is DailyExchangePlan) {
      exchangePlan = args["exchange_plan"] as DailyExchangePlan;
    } else if (args["exchange_plan_json"] is Map) {
      exchangePlan = DailyExchangePlan.fromJson(
        Map<String, dynamic>.from(args["exchange_plan_json"] as Map),
      );
    }

    final fromWizard = distribution.isNotEmpty &&
        periods.isNotEmpty &&
        targets != null &&
        exchangePlan != null;

    return GetBuilder<DietController>(
      builder: (c) {
        if (patientId > 0 && c.patientIdController.text != patientId.toString()) {
          c.patientIdController.text = patientId.toString();
        }
        if (patientName.isNotEmpty && c.titleController.text.isEmpty) {
          c.titleController.text = "Diet plan for $patientName";
        }
        if (fromWizard) {
          if (c.dailyCaloriesController.text.isEmpty) {
            c.dailyCaloriesController.text =
                targets.targetCalories.round().toString();
          }
          if (c.durationDaysController.text.isEmpty) {
            c.durationDaysController.text = "30";
          }
          if (c.startDateController.text.isEmpty) {
            final start = DateTime.now();
            c.startDateController.text =
                "${start.year}-${start.month.toString().padLeft(2, '0')}-${start.day.toString().padLeft(2, '0')}";
          }
          if (c.endDateController.text.isEmpty) {
            final days = int.tryParse(c.durationDaysController.text) ?? 30;
            final end = DateTime.now().add(Duration(days: days));
            c.endDateController.text =
                "${end.year}-${end.month.toString().padLeft(2, '0')}-${end.day.toString().padLeft(2, '0')}";
          }
        }

        return SafeArea(
          child: Scaffold(
            backgroundColor: Colors.grey.shade100,
            appBar: CustomAppBar(
              title: "createDietPlan".tr,
              showBackButton: true,
              showLogo: true,
            ),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (patientName.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: AppColor.shadowColor.withOpacity(0.12),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Text(
                          "Patient: $patientName",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey.shade800,
                          ),
                        ),
                      ),
                    ),
                  if (periods.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColor.primary.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: AppColor.primary.withOpacity(0.3),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "savedMealTimes".tr,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: AppColor.primary,
                              ),
                            ),
                            const SizedBox(height: 8),
                            ...periods.map((p) {
                              final customName = p["custom_name"]?.toString();
                              final type = customName != null &&
                                      customName.isNotEmpty
                                  ? customName
                                  : (p["meal_type"]?.toString() ?? "");
                              final h = p["hour"] ?? 0;
                              final m = p["minute"] ?? 0;
                              final timeStr =
                                  "${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}";
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text(
                                  "$type: $timeStr",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.grey.shade800,
                                  ),
                                ),
                              );
                            }),
                          ],
                        ),
                      ),
                    ),
                  if (fromWizard && targets != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: AppColor.shadowColor.withOpacity(0.12),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${"targetCalories".tr}: ${targets.targetCalories.round()} kcal",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey.shade800,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Carbs: ${targets.macros.carbsG.round()}g | "
                              "Protein: ${targets.macros.proteinG.round()}g | "
                              "Fat: ${targets.macros.fatG.round()}g",
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  TextField(
                    controller: c.patientIdController,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: "patientId".tr,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: c.titleController,
                    decoration: InputDecoration(
                      labelText: "title".tr,
                      hintText: "e.g. Weight loss plan",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: c.dailyCaloriesController,
                    decoration: InputDecoration(
                      labelText: "dailyCalories".tr,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: c.durationDaysController,
                    decoration: InputDecoration(
                      labelText: "durationDays".tr,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: c.startDateController,
                    decoration: InputDecoration(
                      labelText: "startDate".tr,
                      hintText: "2024-01-01",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: c.endDateController,
                    decoration: InputDecoration(
                      labelText: "endDate".tr,
                      hintText: "2024-01-31",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      onPressed: c.createStatus == StatusRequest.loading
                          ? null
                          : () => _onCreate(
                                c,
                                patientId,
                                doctorId,
                                periods,
                                distribution,
                                exchangePlan,
                              ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColor.primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: c.createStatus == StatusRequest.loading
                          ? const SizedBox(
                              height: 22,
                              width: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text("create".tr),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _onCreate(
    DietController c,
    int patientId,
    int doctorId,
    List<Map<String, dynamic>> periods,
    Map<String, Map<String, int>> distribution,
    DailyExchangePlan? exchangePlan,
  ) {
    final pid = int.tryParse(c.patientIdController.text);
    final dailyCalories = int.tryParse(c.dailyCaloriesController.text);
    final durationDays = int.tryParse(c.durationDaysController.text);
    if (pid == null ||
        doctorId == 0 ||
        c.titleController.text.isEmpty ||
        dailyCalories == null ||
        durationDays == null ||
        c.startDateController.text.isEmpty ||
        c.endDateController.text.isEmpty) {
      Get.snackbar("error".tr, "fillFields".tr);
      return;
    }

    List<Map<String, dynamic>>? meals;
    List<Map<String, dynamic>>? mealPeriods;

    if (distribution.isNotEmpty &&
        periods.isNotEmpty &&
        exchangePlan != null) {
      meals = DietPayloadBuilder.buildMeals(
        distribution: distribution,
        periods: periods,
        exchangePlan: exchangePlan,
      );
      mealPeriods = DietPayloadBuilder.buildMealPeriods(periods);
    }

    c.createDietPlan(
      patientId: pid,
      doctorId: doctorId,
      title: c.titleController.text,
      dailyCalories: dailyCalories,
      durationDays: durationDays,
      startDate: c.startDateController.text,
      endDate: c.endDateController.text,
      meals: meals,
      mealPeriods: mealPeriods,
      onSuccess: () {
        Get.until((route) => route.settings.name == AppRoute.patientDetails);
      },
    );
  }
}
