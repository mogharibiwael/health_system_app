import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/class/status_request.dart';
import '../../../core/constant/theme/colors.dart';
import '../../../core/shared/widgets/app_bar.dart';
import '../controller/doctor_details_controller.dart';

class DoctorDetailsPage extends GetView<DoctorDetailsController> {
  const DoctorDetailsPage({super.key});

  static const Color _darkPurple = Color(0xff4a3f6a);
  static const Color _lightBlue = Color(0xffe8f4f8);
  static const Color _lightPurplePink = Color(0xffe4dce8);
  static const Color _lightPurplePinkDarker = Color(0xffd4c8d8);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DoctorDetailsController>(
      builder: (c) => SafeArea(
        child: Scaffold(
          backgroundColor: Colors.grey.shade200,
          appBar: CustomAppBar(
            title: "doctorDetails".tr,
            showBackButton: true,
            showLogo: true,
          ),
          body: Stack(
            children: [
              Row(
                children: [
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                      children: [
                        const SizedBox(height: 8),
                        // Top section - light grey background
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 24),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: Column(
                            children: [
                              // Circular illustration (light blue inner)
                              Center(
                                child: Container(
                                  width: 180,
                                  height: 180,
                                  decoration: BoxDecoration(
                                    color: _lightBlue,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.white, width: 4),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.08),
                                        blurRadius: 16,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: Icon(
                                    Icons.medical_services_rounded,
                                    size: 88,
                                    color: _darkPurple,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Name banner - light purple/pink gradient, dark purple text
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 24),
                                child: Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        _lightPurplePink,
                                        _lightPurplePinkDarker,
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.06),
                                        blurRadius: 10,
                                        offset: const Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: Text(
                                    _doctorDisplayName(c.doctor.name),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w700,
                                      color: _darkPurple,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                        // Details section - white background
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.06),
                                blurRadius: 12,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _DetailRow(
                                icon: Icons.email_outlined,
                                label: "personalEmail".tr,
                                value: c.doctor.email ?? "-",
                              ),
                              const SizedBox(height: 18),
                              _DetailRow(
                                icon: Icons.phone_outlined,
                                label: "phone".tr,
                                value: c.doctor.phone ?? "-",
                              ),
                              const SizedBox(height: 18),
                              _DetailRow(
                                icon: Icons.account_balance_outlined,
                                label: "bankAccount".tr,
                                value: c.doctor.bankAccount ?? "-",
                              ),
                              const SizedBox(height: 18),
                              _DetailRow(
                                icon: Icons.payments_outlined,
                                label: "dietPrice".tr,
                                value: _formatFee(c.doctor.consultationFee),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: c.statusRequest == StatusRequest.loading
                                ? null
                                : (c.isSubscribed ? c.goToChat : c.openVirtualPaymentSheet),
                            icon: Icon(c.isSubscribed ? Icons.chat_bubble_outline : Icons.lock_outline),
                            label: Text(c.isSubscribed ? "chat".tr : "subscribe".tr),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColor.primary,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Dark purple strip on right edge
                  Container(
                    width: 8,
                    decoration: BoxDecoration(
                      color: _darkPurple,
                    ),
                  ),
                ],
              ),
              if (c.statusRequest == StatusRequest.loading) const _LoadingOverlay(),
            ],
          ),
        ),
      ),
    );
  }

  String _doctorDisplayName(String name) {
    if (name.startsWith("د.") || name.startsWith("Dr.")) return name;
    return Get.locale?.languageCode == 'ar' ? "د. $name" : "Dr. $name";
  }

  String _formatFee(String? fee) {
    if (fee == null || fee.isEmpty) return "-";
    final trimmed = fee.trim();
    if (trimmed.contains("\$") || trimmed.toUpperCase().contains("USD")) return trimmed;
    return "\$$trimmed";
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  static const Color _labelPurple = Color(0xff4a3f6a);
  static const Color _iconDark = Color(0xff333333);

  @override
  Widget build(BuildContext context) {
    final isAr = Get.locale?.languageCode == 'ar';

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (isAr) ...[
          Expanded(
            child: RichText(
              textAlign: TextAlign.right,
              text: TextSpan(
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey.shade700,
                  height: 1.4,
                ),
                children: [
                  TextSpan(text: value),
                  TextSpan(
                    text: " : $label",
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: _labelPurple,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 14),
          Icon(icon, size: 24, color: _iconDark),
        ] else ...[
          Icon(icon, size: 24, color: _iconDark),
          const SizedBox(width: 14),
          Expanded(
            child: RichText(
              textAlign: TextAlign.left,
              text: TextSpan(
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey.shade700,
                  height: 1.4,
                ),
                children: [
                  TextSpan(
                    text: "$label : ",
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: _labelPurple,
                    ),
                  ),
                  TextSpan(text: value),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class _LoadingOverlay extends StatelessWidget {
  const _LoadingOverlay();

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.25),
        child: const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
