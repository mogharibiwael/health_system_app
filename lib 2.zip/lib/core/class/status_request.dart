enum StatusRequest { loading, success, failure, serverFailure, offlineFailure, rateLimit }
